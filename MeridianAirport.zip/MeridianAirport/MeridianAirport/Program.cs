﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace MeridianTerminalOperations
{
    // =========================================================
    // ENUMS
    // =========================================================

    public enum FlightType
    {
        Domestic,
        International
    }

    public enum FlightStatus
    {
        Scheduled,
        Delayed,
        Boarding,
        Departed,
        Cancelled
    }

    public enum PassengerCategory
    {
        Standard,
        VIP,
        ReducedMobility
    }

    public enum BookingStatus
    {
        Confirmed,
        Standby,
        Boarded,
        Cancelled
    }

    public enum AssignmentTargetType
    {
        Flight,
        GateOrFacility
    }

    // =========================================================
    // RULES / CONSTANTS
    // =========================================================

    public static class AirportRules
    {
        // Design decisions required by the assignment.
        public const int MinimumConnectionMinutes = 45;
        public const int StandbyListCapacity = 5;

        public const double MaximumStaffDutyHoursPerShift = 8.0;

        public const double MaximumSingleBagWeightKg = 23.0;

        public const double StandardBaggageAllowanceKg = 30.0;
        public const double VipBaggageAllowanceKg = 40.0;
        public const double ReducedMobilityBaggageAllowanceKg = 30.0;
    }

    // =========================================================
    // RESULT CLASS
    // =========================================================

    public class OperationResult
    {
        public bool Success { get; }
        public string Message { get; }

        public OperationResult(bool success, string message)
        {
            Success = success;
            Message = message;
        }

        public static OperationResult Ok(string message)
        {
            return new OperationResult(true, message);
        }

        public static OperationResult Fail(string message)
        {
            return new OperationResult(false, message);
        }
    }

    // =========================================================
    // MODELS
    // =========================================================

    public class Flight
    {
        public string FlightNumber { get; }
        public FlightType Type { get; }

        public DateTime ScheduledArrival { get; }
        public DateTime ScheduledDeparture { get; }

        public int SeatCapacity { get; }

        public string? GateNumber { get; private set; }

        public FlightStatus Status { get; private set; }

        // Gate occupancy is defined as:
        // Scheduled Arrival -> Scheduled Departure
        public DateTime GateOccupancyStart
        {
            get { return ScheduledArrival; }
        }

        public DateTime GateOccupancyEnd
        {
            get { return ScheduledDeparture; }
        }

        public bool RequiresInternationalGate
        {
            get { return Type == FlightType.International; }
        }

        public Flight(
            string flightNumber,
            FlightType type,
            DateTime scheduledArrival,
            DateTime scheduledDeparture,
            int seatCapacity)
        {
            FlightNumber = flightNumber;
            Type = type;
            ScheduledArrival = scheduledArrival;
            ScheduledDeparture = scheduledDeparture;
            SeatCapacity = seatCapacity;
            Status = FlightStatus.Scheduled;
        }

        public void AssignGate(string gateNumber)
        {
            GateNumber = gateNumber;
        }

        public void UpdateStatus(FlightStatus status)
        {
            Status = status;
        }
    }

    public class Gate
    {
        public string GateNumber { get; }
        public TimeSpan AvailabilityStart { get; }
        public TimeSpan AvailabilityEnd { get; }
        public bool SupportsInternational { get; }

        public Gate(
            string gateNumber,
            TimeSpan availabilityStart,
            TimeSpan availabilityEnd,
            bool supportsInternational)
        {
            GateNumber = gateNumber;
            AvailabilityStart = availabilityStart;
            AvailabilityEnd = availabilityEnd;
            SupportsInternational = supportsInternational;
        }

        public bool IsAvailableFor(DateTime start, DateTime end)
        {
            return IsTimeInsideWindow(start.TimeOfDay)
                   && IsTimeInsideWindow(end.TimeOfDay);
        }

        private bool IsTimeInsideWindow(TimeSpan time)
        {
            if (AvailabilityStart <= AvailabilityEnd)
            {
                return time >= AvailabilityStart &&
                       time <= AvailabilityEnd;
            }

            // Supports availability windows that cross midnight.
            return time >= AvailabilityStart ||
                   time <= AvailabilityEnd;
        }
    }

    public class Passenger
    {
        public string PassengerId { get; }
        public string Name { get; }
        public PassengerCategory Category { get; }

        public string? ConnectingFromFlightNumber { get; }

        public Passenger(
            string passengerId,
            string name,
            PassengerCategory category,
            string? connectingFromFlightNumber)
        {
            PassengerId = passengerId;
            Name = name;
            Category = category;
            ConnectingFromFlightNumber = connectingFromFlightNumber;
        }
    }

    public class Baggage
    {
        public string BaggageId { get; }
        public string PassengerId { get; }
        public string FlightNumber { get; }
        public double WeightKg { get; }

        public Baggage(
            string baggageId,
            string passengerId,
            string flightNumber,
            double weightKg)
        {
            BaggageId = baggageId;
            PassengerId = passengerId;
            FlightNumber = flightNumber;
            WeightKg = weightKg;
        }
    }

    public class Booking
    {
        public string BookingId { get; }
        public string PassengerId { get; }
        public string FlightNumber { get; }

        public BookingStatus Status { get; private set; }

        public DateTime CreatedAt { get; }

        public Booking(
            string bookingId,
            string passengerId,
            string flightNumber,
            BookingStatus status)
        {
            BookingId = bookingId;
            PassengerId = passengerId;
            FlightNumber = flightNumber;
            Status = status;
            CreatedAt = DateTime.Now;
        }

        public void Confirm()
        {
            Status = BookingStatus.Confirmed;
        }

        public void Board()
        {
            Status = BookingStatus.Boarded;
        }

        public void Cancel()
        {
            Status = BookingStatus.Cancelled;
        }
    }

    public class GroundStaff
    {
        public string StaffId { get; }
        public string Name { get; }

        public GroundStaff(string staffId, string name)
        {
            StaffId = staffId;
            Name = name;
        }
    }

    public class StaffAssignment
    {
        public string AssignmentId { get; }

        public string StaffId { get; }

        public AssignmentTargetType TargetType { get; }

        public string TargetName { get; }

        public DateTime StartTime { get; }

        public DateTime EndTime { get; }

        public double DurationHours
        {
            get
            {
                return (EndTime - StartTime).TotalHours;
            }
        }

        public StaffAssignment(
            string assignmentId,
            string staffId,
            AssignmentTargetType targetType,
            string targetName,
            DateTime startTime,
            DateTime endTime)
        {
            AssignmentId = assignmentId;
            StaffId = staffId;
            TargetType = targetType;
            TargetName = targetName;
            StartTime = startTime;
            EndTime = endTime;
        }
    }

    // =========================================================
    // INTERFACES
    // =========================================================

    public interface IRepository<T>
    {
        IReadOnlyList<T> GetAll();
        void Add(T item);
    }

    public interface IBaggageAllowancePolicy
    {
        double GetAllowanceKg(PassengerCategory category);
    }

    // =========================================================
    // GENERIC IN-MEMORY REPOSITORY
    // =========================================================

    public class InMemoryRepository<T> : IRepository<T>
    {
        private readonly List<T> items = new List<T>();

        public IReadOnlyList<T> GetAll()
        {
            return items;
        }

        public void Add(T item)
        {
            items.Add(item);
        }
    }

    // =========================================================
    // BAGGAGE POLICY
    // Strategy-style class
    // =========================================================

    public class DefaultBaggageAllowancePolicy
        : IBaggageAllowancePolicy
    {
        public double GetAllowanceKg(PassengerCategory category)
        {
            switch (category)
            {
                case PassengerCategory.Standard:
                    return AirportRules.StandardBaggageAllowanceKg;

                case PassengerCategory.VIP:
                    return AirportRules.VipBaggageAllowanceKg;

                case PassengerCategory.ReducedMobility:
                    return AirportRules.ReducedMobilityBaggageAllowanceKg;

                default:
                    return AirportRules.StandardBaggageAllowanceKg;
            }
        }
    }

    // =========================================================
    // FLIGHT SERVICE
    // =========================================================

    public class FlightService
    {
        private readonly IRepository<Flight> flightRepository;
        private readonly IRepository<Gate> gateRepository;

        public FlightService(
            IRepository<Flight> flightRepository,
            IRepository<Gate> gateRepository)
        {
            this.flightRepository = flightRepository;
            this.gateRepository = gateRepository;
        }

        public OperationResult RegisterFlight(
            string flightNumber,
            FlightType type,
            DateTime scheduledArrival,
            DateTime scheduledDeparture,
            int seatCapacity)
        {
            bool alreadyExists = flightRepository
                .GetAll()
                .Any(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));

            if (alreadyExists)
            {
                return OperationResult.Fail(
                    "FLIGHT REGISTRATION FAILED: Flight number already exists.");
            }

            if (scheduledArrival >= scheduledDeparture)
            {
                return OperationResult.Fail(
                    "FLIGHT REGISTRATION FAILED: Scheduled arrival must be earlier than scheduled departure.");
            }

            if (seatCapacity <= 0)
            {
                return OperationResult.Fail(
                    "FLIGHT REGISTRATION FAILED: Seat capacity must be greater than zero.");
            }

            Flight flight = new Flight(
                flightNumber,
                type,
                scheduledArrival,
                scheduledDeparture,
                seatCapacity);

            flightRepository.Add(flight);

            return OperationResult.Ok(
                $"FLIGHT REGISTERED SUCCESSFULLY: {flightNumber}.");
        }

        public OperationResult AssignGate(
            string flightNumber,
            string gateNumber)
        {
            Flight? flight = GetFlight(flightNumber);

            if (flight == null)
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: Flight does not exist.");
            }

            Gate? gate = gateRepository
                .GetAll()
                .FirstOrDefault(g =>
                    g.GateNumber.Equals(
                        gateNumber,
                        StringComparison.OrdinalIgnoreCase));

            if (gate == null)
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: Gate does not exist.");
            }

            if (flight.Status == FlightStatus.Departed ||
                flight.Status == FlightStatus.Cancelled)
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: A departed or cancelled flight cannot be assigned a gate.");
            }

            if (flight.RequiresInternationalGate &&
                !gate.SupportsInternational)
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: This international flight requires an international-capable gate.");
            }

            if (!gate.IsAvailableFor(
                    flight.GateOccupancyStart,
                    flight.GateOccupancyEnd))
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: The flight's gate-occupancy window is outside this gate's availability.");
            }

            bool overlappingFlightExists = flightRepository
                .GetAll()
                .Any(other =>
                    !other.FlightNumber.Equals(
                        flight.FlightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    other.GateNumber != null
                    &&
                    other.GateNumber.Equals(
                        gate.GateNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    WindowsOverlap(
                        flight.GateOccupancyStart,
                        flight.GateOccupancyEnd,
                        other.GateOccupancyStart,
                        other.GateOccupancyEnd));

            if (overlappingFlightExists)
            {
                return OperationResult.Fail(
                    "GATE ASSIGNMENT FAILED: This gate is already occupied by another flight during an overlapping time window.");
            }

            flight.AssignGate(gate.GateNumber);

            return OperationResult.Ok(
                $"GATE ASSIGNED SUCCESSFULLY: {flight.FlightNumber} -> Gate {gate.GateNumber}.");
        }

        public OperationResult UpdateFlightStatus(
            string flightNumber,
            FlightStatus newStatus)
        {
            Flight? flight = GetFlight(flightNumber);

            if (flight == null)
            {
                return OperationResult.Fail(
                    "STATUS UPDATE FAILED: Flight does not exist.");
            }

            flight.UpdateStatus(newStatus);

            return OperationResult.Ok(
                $"FLIGHT STATUS UPDATED: {flight.FlightNumber} -> {flight.Status}.");
        }

        public Flight? GetFlight(string flightNumber)
        {
            return flightRepository
                .GetAll()
                .FirstOrDefault(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));
        }

        public IReadOnlyList<Flight> GetAllFlights()
        {
            return flightRepository.GetAll();
        }

        public IReadOnlyList<Gate> GetAllGates()
        {
            return gateRepository.GetAll();
        }

        private bool WindowsOverlap(
            DateTime start1,
            DateTime end1,
            DateTime start2,
            DateTime end2)
        {
            return start1 < end2 &&
                   start2 < end1;
        }
    }

    // =========================================================
    // PASSENGER SERVICE
    // =========================================================

    public class PassengerService
    {
        private readonly IRepository<Passenger> passengerRepository;
        private readonly IRepository<Flight> flightRepository;

        public PassengerService(
            IRepository<Passenger> passengerRepository,
            IRepository<Flight> flightRepository)
        {
            this.passengerRepository = passengerRepository;
            this.flightRepository = flightRepository;
        }

        public OperationResult RegisterPassenger(
            string passengerId,
            string name,
            PassengerCategory category,
            string? connectingFromFlightNumber)
        {
            bool alreadyExists = passengerRepository
                .GetAll()
                .Any(p =>
                    p.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase));

            if (alreadyExists)
            {
                return OperationResult.Fail(
                    "PASSENGER REGISTRATION FAILED: Passenger ID already exists.");
            }

            if (connectingFromFlightNumber != null)
            {
                bool connectingFlightExists = flightRepository
                    .GetAll()
                    .Any(f =>
                        f.FlightNumber.Equals(
                            connectingFromFlightNumber,
                            StringComparison.OrdinalIgnoreCase));

                if (!connectingFlightExists)
                {
                    return OperationResult.Fail(
                        "PASSENGER REGISTRATION FAILED: The connecting flight does not exist.");
                }
            }

            Passenger passenger = new Passenger(
                passengerId,
                name,
                category,
                connectingFromFlightNumber);

            passengerRepository.Add(passenger);

            return OperationResult.Ok(
                $"PASSENGER REGISTERED SUCCESSFULLY: {passengerId}.");
        }

        public Passenger? GetPassenger(string passengerId)
        {
            return passengerRepository
                .GetAll()
                .FirstOrDefault(p =>
                    p.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase));
        }

        public IReadOnlyList<Passenger> GetAllPassengers()
        {
            return passengerRepository.GetAll();
        }
    }

    // =========================================================
    // BOOKING SERVICE
    // =========================================================

    public class BookingService
    {
        private readonly IRepository<Booking> bookingRepository;
        private readonly IRepository<Passenger> passengerRepository;
        private readonly IRepository<Flight> flightRepository;

        private int nextBookingNumber = 1001;

        public BookingService(
            IRepository<Booking> bookingRepository,
            IRepository<Passenger> passengerRepository,
            IRepository<Flight> flightRepository)
        {
            this.bookingRepository = bookingRepository;
            this.passengerRepository = passengerRepository;
            this.flightRepository = flightRepository;
        }

        public OperationResult BookPassenger(
            string passengerId,
            string flightNumber)
        {
            Passenger? passenger = GetPassenger(passengerId);

            if (passenger == null)
            {
                return OperationResult.Fail(
                    "BOOKING FAILED: Passenger does not exist.");
            }

            Flight? flight = GetFlight(flightNumber);

            if (flight == null)
            {
                return OperationResult.Fail(
                    "BOOKING FAILED: Flight does not exist.");
            }

            if (flight.Status == FlightStatus.Departed ||
                flight.Status == FlightStatus.Cancelled)
            {
                return OperationResult.Fail(
                    "BOOKING FAILED: A departed or cancelled flight cannot accept new bookings.");
            }

            bool alreadyBooked = bookingRepository
                .GetAll()
                .Any(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status != BookingStatus.Cancelled);

            if (alreadyBooked)
            {
                return OperationResult.Fail(
                    "BOOKING FAILED: Passenger already has an active booking on this flight.");
            }

            int occupiedSeats = bookingRepository
                .GetAll()
                .Count(b =>
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    (b.Status == BookingStatus.Confirmed ||
                     b.Status == BookingStatus.Boarded));

            BookingStatus bookingStatus;

            if (occupiedSeats < flight.SeatCapacity)
            {
                bookingStatus = BookingStatus.Confirmed;
            }
            else
            {
                int standbyCount = bookingRepository
                    .GetAll()
                    .Count(b =>
                        b.FlightNumber.Equals(
                            flightNumber,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        b.Status == BookingStatus.Standby);

                if (standbyCount >= AirportRules.StandbyListCapacity)
                {
                    return OperationResult.Fail(
                        "BOOKING FAILED: Flight is full and the standby list has reached its maximum capacity.");
                }

                bookingStatus = BookingStatus.Standby;
            }

            string bookingId =
                $"B-{nextBookingNumber++}";

            Booking booking = new Booking(
                bookingId,
                passengerId,
                flightNumber,
                bookingStatus);

            bookingRepository.Add(booking);

            if (bookingStatus == BookingStatus.Confirmed)
            {
                return OperationResult.Ok(
                    $"BOOKING CONFIRMED: Booking ID {bookingId}.");
            }

            int standbyPosition =
                GetStandbyPosition(bookingId, flightNumber);

            return OperationResult.Ok(
                $"FLIGHT FULL: Passenger placed on standby. Booking ID {bookingId}. Standby position: {standbyPosition}.");
        }

        public OperationResult CancelConfirmedBooking(
            string passengerId,
            string flightNumber)
        {
            Booking? booking = bookingRepository
                .GetAll()
                .FirstOrDefault(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status == BookingStatus.Confirmed);

            if (booking == null)
            {
                return OperationResult.Fail(
                    "CANCELLATION FAILED: No confirmed booking was found for this passenger and flight.");
            }

            booking.Cancel();

            Booking? earliestStandby = GetStandbyList(flightNumber)
                .FirstOrDefault();

            if (earliestStandby != null)
            {
                earliestStandby.Confirm();

                return OperationResult.Ok(
                    $"BOOKING CANCELLED: Freed seat automatically promoted passenger {earliestStandby.PassengerId} from standby to confirmed.");
            }

            return OperationResult.Ok(
                "BOOKING CANCELLED: No standby passenger was waiting.");
        }

        public Booking? GetConfirmedBooking(
            string passengerId,
            string flightNumber)
        {
            return bookingRepository
                .GetAll()
                .FirstOrDefault(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    (b.Status == BookingStatus.Confirmed ||
                     b.Status == BookingStatus.Boarded));
        }

        public Booking? GetStandbyBooking(
            string passengerId,
            string flightNumber)
        {
            return bookingRepository
                .GetAll()
                .FirstOrDefault(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status == BookingStatus.Standby);
        }

        public IReadOnlyList<Booking> GetStandbyList(
            string flightNumber)
        {
            return bookingRepository
                .GetAll()
                .Where(b =>
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status == BookingStatus.Standby)
                .OrderBy(b => b.CreatedAt)
                .ToList();
        }

        public IReadOnlyList<Booking> GetAllBookings()
        {
            return bookingRepository.GetAll();
        }

        private int GetStandbyPosition(
            string bookingId,
            string flightNumber)
        {
            List<Booking> standby =
                GetStandbyList(flightNumber).ToList();

            int index = standby.FindIndex(
                b => b.BookingId == bookingId);

            return index + 1;
        }

        private Passenger? GetPassenger(string passengerId)
        {
            return passengerRepository
                .GetAll()
                .FirstOrDefault(p =>
                    p.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase));
        }

        private Flight? GetFlight(string flightNumber)
        {
            return flightRepository
                .GetAll()
                .FirstOrDefault(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));
        }
    }

    // =========================================================
    // BOARDING SERVICE
    // =========================================================

    public class BoardingService
    {
        private readonly IRepository<Flight> flightRepository;
        private readonly IRepository<Passenger> passengerRepository;
        private readonly IRepository<Booking> bookingRepository;

        public BoardingService(
            IRepository<Flight> flightRepository,
            IRepository<Passenger> passengerRepository,
            IRepository<Booking> bookingRepository)
        {
            this.flightRepository = flightRepository;
            this.passengerRepository = passengerRepository;
            this.bookingRepository = bookingRepository;
        }

        public OperationResult CheckBoardingEligibility(
            string passengerId,
            string flightNumber)
        {
            Passenger? passenger = GetPassenger(passengerId);

            if (passenger == null)
            {
                return OperationResult.Fail(
                    "BOARDING DENIED: Passenger does not exist.");
            }

            Flight? nextFlight = GetFlight(flightNumber);

            if (nextFlight == null)
            {
                return OperationResult.Fail(
                    "BOARDING DENIED: Flight does not exist.");
            }

            if (nextFlight.Status == FlightStatus.Departed)
            {
                return OperationResult.Fail(
                    "BOARDING DENIED: Flight has already departed.");
            }

            if (nextFlight.Status == FlightStatus.Cancelled)
            {
                return OperationResult.Fail(
                    "BOARDING DENIED: Flight is cancelled.");
            }

            if (nextFlight.Status != FlightStatus.Boarding)
            {
                return OperationResult.Fail(
                    $"BOARDING DENIED: Flight status is {nextFlight.Status}. Boarding is allowed only when the flight is marked Boarding.");
            }

            Booking? confirmedBooking = bookingRepository
                .GetAll()
                .FirstOrDefault(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status == BookingStatus.Confirmed);

            if (confirmedBooking == null)
            {
                bool onStandby = bookingRepository
                    .GetAll()
                    .Any(b =>
                        b.PassengerId.Equals(
                            passengerId,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        b.FlightNumber.Equals(
                            flightNumber,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        b.Status == BookingStatus.Standby);

                if (onStandby)
                {
                    return OperationResult.Fail(
                        "BOARDING DENIED: Passenger is still on the standby list and does not have a confirmed seat.");
                }

                return OperationResult.Fail(
                    "BOARDING DENIED: Passenger does not have a confirmed booking for this flight.");
            }

            if (passenger.ConnectingFromFlightNumber != null)
            {
                if (passenger.ConnectingFromFlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase))
                {
                    return OperationResult.Fail(
                        "BOARDING DENIED: The connecting flight and the next flight cannot be the same flight.");
                }

                Flight? connectingFlight = GetFlight(
                    passenger.ConnectingFromFlightNumber);

                if (connectingFlight == null)
                {
                    return OperationResult.Fail(
                        "BOARDING DENIED: The passenger's connecting arrival flight could not be found.");
                }

                double connectionMinutes =
                    (nextFlight.ScheduledDeparture -
                     connectingFlight.ScheduledArrival).TotalMinutes;

                if (connectionMinutes <
                    AirportRules.MinimumConnectionMinutes)
                {
                    int displayedMinutes =
                        Math.Max(0, (int)connectionMinutes);

                    return OperationResult.Fail(
                        $"BOARDING DENIED: Only {displayedMinutes} minutes remain between the connecting flight's arrival and the next flight's departure; the minimum connection time is {AirportRules.MinimumConnectionMinutes} minutes.");
                }
            }

            return OperationResult.Ok(
                $"BOARDING ELIGIBLE: Passenger {passenger.Name} may board flight {flightNumber}.");
        }

        public OperationResult ProcessBoarding(
            string passengerId,
            string flightNumber)
        {
            OperationResult eligibility =
                CheckBoardingEligibility(
                    passengerId,
                    flightNumber);

            if (!eligibility.Success)
            {
                return eligibility;
            }

            Booking? booking = bookingRepository
                .GetAll()
                .FirstOrDefault(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.Status == BookingStatus.Confirmed);

            if (booking == null)
            {
                return OperationResult.Fail(
                    "BOARDING FAILED: Confirmed booking could not be found.");
            }

            booking.Board();

            return OperationResult.Ok(
                $"BOARDING SUCCESSFUL: Passenger {passengerId} boarded flight {flightNumber}.");
        }

        private Passenger? GetPassenger(string passengerId)
        {
            return passengerRepository
                .GetAll()
                .FirstOrDefault(p =>
                    p.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase));
        }

        private Flight? GetFlight(string flightNumber)
        {
            return flightRepository
                .GetAll()
                .FirstOrDefault(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));
        }
    }

    // =========================================================
    // BAGGAGE SERVICE
    // =========================================================

    public class BaggageService
    {
        private readonly IRepository<Baggage> baggageRepository;
        private readonly IRepository<Passenger> passengerRepository;
        private readonly IRepository<Flight> flightRepository;
        private readonly IRepository<Booking> bookingRepository;

        private readonly IBaggageAllowancePolicy allowancePolicy;

        private int nextBaggageNumber = 1001;

        public BaggageService(
            IRepository<Baggage> baggageRepository,
            IRepository<Passenger> passengerRepository,
            IRepository<Flight> flightRepository,
            IRepository<Booking> bookingRepository,
            IBaggageAllowancePolicy allowancePolicy)
        {
            this.baggageRepository = baggageRepository;
            this.passengerRepository = passengerRepository;
            this.flightRepository = flightRepository;
            this.bookingRepository = bookingRepository;
            this.allowancePolicy = allowancePolicy;
        }

        public OperationResult RegisterBaggage(
            string passengerId,
            string flightNumber,
            double weightKg)
        {
            Passenger? passenger = GetPassenger(passengerId);

            if (passenger == null)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Passenger does not exist.");
            }

            Flight? flight = GetFlight(flightNumber);

            if (flight == null)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Flight does not exist.");
            }

            if (flight.Status == FlightStatus.Departed)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Flight has already departed.");
            }

            if (flight.Status == FlightStatus.Cancelled)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Flight is cancelled.");
            }

            if (weightKg <= 0)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Baggage weight must be greater than zero.");
            }

            if (weightKg >
                AirportRules.MaximumSingleBagWeightKg)
            {
                return OperationResult.Fail(
                    $"BAGGAGE REJECTED: A single bag cannot exceed {AirportRules.MaximumSingleBagWeightKg:0.#}kg.");
            }

            bool hasConfirmedSeat = bookingRepository
                .GetAll()
                .Any(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    (b.Status == BookingStatus.Confirmed ||
                     b.Status == BookingStatus.Boarded));

            if (!hasConfirmedSeat)
            {
                return OperationResult.Fail(
                    "BAGGAGE REJECTED: Passenger must have a confirmed seat before baggage can be registered.");
            }

            double currentTotal =
                GetTotalWeight(
                    passengerId,
                    flightNumber);

            double allowance =
                allowancePolicy.GetAllowanceKg(
                    passenger.Category);

            double newTotal =
                currentTotal + weightKg;

            if (newTotal > allowance)
            {
                return OperationResult.Fail(
                    $"BAGGAGE REJECTED: This bag would bring the passenger's total checked baggage to {newTotal:0.##}kg, exceeding the {allowance:0.#}kg allowance for {passenger.Category} passengers.");
            }

            string baggageId =
                $"BG-{nextBaggageNumber++}";

            Baggage baggage = new Baggage(
                baggageId,
                passengerId,
                flightNumber,
                weightKg);

            baggageRepository.Add(baggage);

            return OperationResult.Ok(
                $"BAGGAGE ACCEPTED: Bag {baggageId} registered. Total baggage weight: {newTotal:0.##}kg / {allowance:0.#}kg.");
        }

        public double GetTotalWeight(
            string passengerId,
            string flightNumber)
        {
            return baggageRepository
                .GetAll()
                .Where(b =>
                    b.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase)
                    &&
                    b.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase))
                .Sum(b => b.WeightKg);
        }

        public double GetAllowanceKg(
            PassengerCategory category)
        {
            return allowancePolicy.GetAllowanceKg(
                category);
        }

        private Passenger? GetPassenger(
            string passengerId)
        {
            return passengerRepository
                .GetAll()
                .FirstOrDefault(p =>
                    p.PassengerId.Equals(
                        passengerId,
                        StringComparison.OrdinalIgnoreCase));
        }

        private Flight? GetFlight(
            string flightNumber)
        {
            return flightRepository
                .GetAll()
                .FirstOrDefault(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));
        }
    }

    // =========================================================
    // STAFF SERVICE
    // =========================================================

    public class StaffService
    {
        private readonly IRepository<GroundStaff> staffRepository;
        private readonly IRepository<StaffAssignment> assignmentRepository;
        private readonly IRepository<Flight> flightRepository;

        private int nextAssignmentNumber = 1001;

        public StaffService(
            IRepository<GroundStaff> staffRepository,
            IRepository<StaffAssignment> assignmentRepository,
            IRepository<Flight> flightRepository)
        {
            this.staffRepository = staffRepository;
            this.assignmentRepository = assignmentRepository;
            this.flightRepository = flightRepository;
        }

        public OperationResult AssignToFlight(
            string staffId,
            string flightNumber)
        {
            GroundStaff? staff = GetStaff(staffId);

            if (staff == null)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: Staff member does not exist.");
            }

            Flight? flight = GetFlight(flightNumber);

            if (flight == null)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: Flight does not exist.");
            }

            if (flight.Status == FlightStatus.Departed ||
                flight.Status == FlightStatus.Cancelled)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: Departed or cancelled flights cannot receive new staff assignments.");
            }

            return CreateAssignment(
                staff,
                AssignmentTargetType.Flight,
                $"Flight {flight.FlightNumber}",
                flight.GateOccupancyStart,
                flight.GateOccupancyEnd);
        }

        public OperationResult AssignToGateOrFacility(
            string staffId,
            string targetName,
            DateTime startTime,
            DateTime endTime)
        {
            GroundStaff? staff = GetStaff(staffId);

            if (staff == null)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: Staff member does not exist.");
            }

            return CreateAssignment(
                staff,
                AssignmentTargetType.GateOrFacility,
                targetName,
                startTime,
                endTime);
        }

        public double GetCumulativeDutyHours(
            string staffId)
        {
            return assignmentRepository
                .GetAll()
                .Where(a =>
                    a.StaffId.Equals(
                        staffId,
                        StringComparison.OrdinalIgnoreCase))
                .Sum(a => a.DurationHours);
        }

        public IReadOnlyList<GroundStaff> GetAllStaff()
        {
            return staffRepository.GetAll();
        }

        public IReadOnlyList<StaffAssignment>
            GetAssignmentsForStaff(string staffId)
        {
            return assignmentRepository
                .GetAll()
                .Where(a =>
                    a.StaffId.Equals(
                        staffId,
                        StringComparison.OrdinalIgnoreCase))
                .OrderBy(a => a.StartTime)
                .ToList();
        }

        private OperationResult CreateAssignment(
            GroundStaff staff,
            AssignmentTargetType targetType,
            string targetName,
            DateTime startTime,
            DateTime endTime)
        {
            if (startTime >= endTime)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: Start time must be earlier than end time.");
            }

            bool overlappingAssignmentExists =
                assignmentRepository
                    .GetAll()
                    .Any(existing =>
                        existing.StaffId.Equals(
                            staff.StaffId,
                            StringComparison.OrdinalIgnoreCase)
                        &&
                        existing.StartTime < endTime
                        &&
                        startTime < existing.EndTime);

            if (overlappingAssignmentExists)
            {
                return OperationResult.Fail(
                    "STAFF ASSIGNMENT FAILED: This staff member already has another assignment during an overlapping time period.");
            }

            double newAssignmentHours =
                (endTime - startTime).TotalHours;

            double currentHours =
                GetCumulativeDutyHours(staff.StaffId);

            double newTotalHours =
                currentHours + newAssignmentHours;

            if (newTotalHours >
                AirportRules.MaximumStaffDutyHoursPerShift)
            {
                return OperationResult.Fail(
                    $"STAFF ASSIGNMENT FAILED: The assignment would raise {staff.Name}'s cumulative duty to {newTotalHours:0.##} hours, exceeding the {AirportRules.MaximumStaffDutyHoursPerShift:0.#}-hour shift limit.");
            }

            string assignmentId =
                $"A-{nextAssignmentNumber++}";

            StaffAssignment assignment =
                new StaffAssignment(
                    assignmentId,
                    staff.StaffId,
                    targetType,
                    targetName,
                    startTime,
                    endTime);

            assignmentRepository.Add(assignment);

            return OperationResult.Ok(
                $"STAFF ASSIGNED SUCCESSFULLY: {staff.Name}. New cumulative duty hours: {newTotalHours:0.##}/{AirportRules.MaximumStaffDutyHoursPerShift:0.#}.");
        }

        private GroundStaff? GetStaff(string staffId)
        {
            return staffRepository
                .GetAll()
                .FirstOrDefault(s =>
                    s.StaffId.Equals(
                        staffId,
                        StringComparison.OrdinalIgnoreCase));
        }

        private Flight? GetFlight(string flightNumber)
        {
            return flightRepository
                .GetAll()
                .FirstOrDefault(f =>
                    f.FlightNumber.Equals(
                        flightNumber,
                        StringComparison.OrdinalIgnoreCase));
        }
    }

    // =========================================================
    // INPUT HELPER
    // =========================================================

    public static class InputHelper
    {
        public static string ReadNonEmpty(
            string message)
        {
            while (true)
            {
                Console.Write(message);

                string? input = Console.ReadLine();

                if (!string.IsNullOrWhiteSpace(input))
                {
                    return input.Trim();
                }

                Console.WriteLine(
                    "Input cannot be empty.");
            }
        }

        public static string? ReadOptional(
            string message)
        {
            Console.Write(message);

            string? input = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(input))
            {
                return null;
            }

            return input.Trim();
        }

        public static int ReadInt(
            string message)
        {
            while (true)
            {
                Console.Write(message);

                string? input = Console.ReadLine();

                if (int.TryParse(
                        input,
                        out int value))
                {
                    return value;
                }

                Console.WriteLine(
                    "Invalid input. Please enter a whole number.");
            }
        }

        public static double ReadDouble(
            string message)
        {
            while (true)
            {
                Console.Write(message);

                string? input = Console.ReadLine();

                bool success = double.TryParse(
                    input,
                    NumberStyles.Float,
                    CultureInfo.InvariantCulture,
                    out double value);

                if (success)
                {
                    return value;
                }

                Console.WriteLine(
                    "Invalid input. Please enter a valid number.");
            }
        }

        public static DateTime ReadDateTime(
            string message)
        {
            while (true)
            {
                Console.Write(message);

                string? input = Console.ReadLine();

                if (DateTime.TryParse(
                        input,
                        out DateTime value))
                {
                    return value;
                }

                Console.WriteLine(
                    "Invalid date/time. Example: 2026-09-01 14:30");
            }
        }

        public static T ReadEnumChoice<T>(
            string title)
            where T : struct, Enum
        {
            T[] values = Enum.GetValues<T>();

            while (true)
            {
                Console.WriteLine();
                Console.WriteLine(title);

                for (int i = 0; i < values.Length; i++)
                {
                    Console.WriteLine(
                        $"{i + 1}. {values[i]}");
                }

                int choice =
                    ReadInt("Choose option: ");

                if (choice >= 1 &&
                    choice <= values.Length)
                {
                    return values[choice - 1];
                }

                Console.WriteLine(
                    "Invalid option. Please try again.");
            }
        }
    }

    // =========================================================
    // PROGRAM
    // =========================================================

    internal class Program
    {
        // =====================================================
        // SESSION-ONLY REPOSITORIES
        // =====================================================

        private static readonly
            IRepository<Flight> flightRepository =
                new InMemoryRepository<Flight>();

        private static readonly
            IRepository<Gate> gateRepository =
                new InMemoryRepository<Gate>();

        private static readonly
            IRepository<Passenger> passengerRepository =
                new InMemoryRepository<Passenger>();

        private static readonly
            IRepository<Booking> bookingRepository =
                new InMemoryRepository<Booking>();

        private static readonly
            IRepository<Baggage> baggageRepository =
                new InMemoryRepository<Baggage>();

        private static readonly
            IRepository<GroundStaff> staffRepository =
                new InMemoryRepository<GroundStaff>();

        private static readonly
            IRepository<StaffAssignment> assignmentRepository =
                new InMemoryRepository<StaffAssignment>();

        // =====================================================
        // SERVICES
        // Dependencies are injected through constructors.
        // =====================================================

        private static readonly FlightService flightService =
            new FlightService(
                flightRepository,
                gateRepository);

        private static readonly PassengerService passengerService =
            new PassengerService(
                passengerRepository,
                flightRepository);

        private static readonly BookingService bookingService =
            new BookingService(
                bookingRepository,
                passengerRepository,
                flightRepository);

        private static readonly BoardingService boardingService =
            new BoardingService(
                flightRepository,
                passengerRepository,
                bookingRepository);

        private static readonly BaggageService baggageService =
            new BaggageService(
                baggageRepository,
                passengerRepository,
                flightRepository,
                bookingRepository,
                new DefaultBaggageAllowancePolicy());

        private static readonly StaffService staffService =
            new StaffService(
                staffRepository,
                assignmentRepository,
                flightRepository);

        // =====================================================
        // MAIN
        // =====================================================

        private static void Main()
        {
            SeedGates();
            SeedStaff();

            Console.WriteLine(
                "============================================================");

            Console.WriteLine(
                "      Meridian Terminal — Ground Operations System");

            Console.WriteLine(
                "============================================================");

            Console.WriteLine(
                "Session data only: data is lost when the program exits.");

            bool exit = false;

            while (!exit)
            {
                ShowMainMenu();

                int choice =
                    InputHelper.ReadInt(
                        "Select an option: ");

                Console.WriteLine();

                switch (choice)
                {
                    case 1:
                        RegisterFlight();
                        break;

                    case 2:
                        AssignGate();
                        break;

                    case 3:
                        UpdateFlightStatus();
                        break;

                    case 4:
                        RegisterPassenger();
                        break;

                    case 5:
                        CheckBoardingEligibility();
                        break;

                    case 6:
                        ProcessBoarding();
                        break;

                    case 7:
                        RegisterBaggage();
                        break;

                    case 8:
                        ViewPassengerBaggageWeight();
                        break;

                    case 9:
                        BookPassenger();
                        break;

                    case 10:
                        CancelBooking();
                        break;

                    case 11:
                        ViewStandbyList();
                        break;

                    case 12:
                        AssignStaff();
                        break;

                    case 13:
                        ViewStaffDutyHours();
                        break;

                    case 14:
                        ViewGates();
                        break;

                    case 15:
                        ViewFlights();
                        break;

                    case 16:
                        ViewPassengers();
                        break;

                    case 17:
                        ViewBookings();
                        break;

                    case 0:
                        exit = true;
                        Console.WriteLine(
                            "Thank you for using Meridian Terminal Operations System.");
                        break;

                    default:
                        Console.WriteLine(
                            "Invalid option. Please choose a valid menu option.");
                        break;
                }

                if (!exit)
                {
                    Console.WriteLine();
                    Console.WriteLine(
                        "Press ENTER to continue...");

                    Console.ReadLine();

                    Console.Clear();
                }
            }
        }

        // =====================================================
        // MAIN MENU
        // =====================================================

        private static void ShowMainMenu()
        {
            Console.WriteLine();
            Console.WriteLine("===================== MAIN MENU =====================");
            Console.WriteLine("1.  Register Flight");
            Console.WriteLine("2.  Assign Flight to Gate");
            Console.WriteLine("3.  Update Flight Status");
            Console.WriteLine("4.  Register Passenger");
            Console.WriteLine("5.  Check Boarding Eligibility");
            Console.WriteLine("6.  Process Boarding");
            Console.WriteLine("7.  Register Baggage");
            Console.WriteLine("8.  View Passenger Cumulative Baggage");
            Console.WriteLine("9.  Book Passenger / Confirm or Standby");
            Console.WriteLine("10. Cancel Confirmed Booking");
            Console.WriteLine("11. View Flight Standby List");
            Console.WriteLine("12. Assign Ground Staff");
            Console.WriteLine("13. View Staff Duty Hours");
            Console.WriteLine("14. View Gates");
            Console.WriteLine("15. View Flights");
            Console.WriteLine("16. View Passengers");
            Console.WriteLine("17. View Bookings");
            Console.WriteLine("0.  Exit");
            Console.WriteLine("=====================================================");
        }

        // =====================================================
        // 1. REGISTER FLIGHT
        // =====================================================

        private static void RegisterFlight()
        {
            Console.WriteLine(
                "========== REGISTER FLIGHT ==========");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            FlightType type =
                InputHelper.ReadEnumChoice<FlightType>(
                    "Choose Flight Type:");

            DateTime arrival =
                InputHelper.ReadDateTime(
                    "Enter Scheduled Arrival (example 2026-09-01 13:00): ");

            DateTime departure =
                InputHelper.ReadDateTime(
                    "Enter Scheduled Departure (example 2026-09-01 14:30): ");

            int capacity =
                InputHelper.ReadInt(
                    "Enter Seat Capacity: ");

            OperationResult result =
                flightService.RegisterFlight(
                    flightNumber,
                    type,
                    arrival,
                    departure,
                    capacity);

            Console.WriteLine(result.Message);

            if (result.Success)
            {
                Console.WriteLine(
                    "Gate rule: international flights require an international-capable gate.");
            }
        }

        // =====================================================
        // 2. ASSIGN GATE
        // =====================================================

        private static void AssignGate()
        {
            Console.WriteLine(
                "========== ASSIGN GATE ==========");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            string gateNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Gate Number: ");

            OperationResult result =
                flightService.AssignGate(
                    flightNumber,
                    gateNumber);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 3. UPDATE FLIGHT STATUS
        // =====================================================

        private static void UpdateFlightStatus()
        {
            Console.WriteLine(
                "========== UPDATE FLIGHT STATUS ==========");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            FlightStatus status =
                InputHelper.ReadEnumChoice<FlightStatus>(
                    "Choose New Flight Status:");

            OperationResult result =
                flightService.UpdateFlightStatus(
                    flightNumber,
                    status);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 4. REGISTER PASSENGER
        // =====================================================

        private static void RegisterPassenger()
        {
            Console.WriteLine(
                "========== REGISTER PASSENGER ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string name =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger Name: ");

            PassengerCategory category =
                InputHelper.ReadEnumChoice<PassengerCategory>(
                    "Choose Passenger Category:");

            string? connectingFlight =
                InputHelper.ReadOptional(
                    "Enter earlier connecting Flight Number (press ENTER for none): ");

            OperationResult result =
                passengerService.RegisterPassenger(
                    passengerId,
                    name,
                    category,
                    connectingFlight);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 5. CHECK BOARDING ELIGIBILITY
        // =====================================================

        private static void CheckBoardingEligibility()
        {
            Console.WriteLine(
                "========== CHECK BOARDING ELIGIBILITY ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Next Flight Number: ");

            OperationResult result =
                boardingService.CheckBoardingEligibility(
                    passengerId,
                    flightNumber);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 6. PROCESS BOARDING
        // =====================================================

        private static void ProcessBoarding()
        {
            Console.WriteLine(
                "========== PROCESS BOARDING ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            OperationResult result =
                boardingService.ProcessBoarding(
                    passengerId,
                    flightNumber);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 7. REGISTER BAGGAGE
        // =====================================================

        private static void RegisterBaggage()
        {
            Console.WriteLine(
                "========== REGISTER BAGGAGE ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            double weight =
                InputHelper.ReadDouble(
                    "Enter Baggage Weight (kg): ");

            OperationResult result =
                baggageService.RegisterBaggage(
                    passengerId,
                    flightNumber,
                    weight);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 8. VIEW BAGGAGE TOTAL
        // =====================================================

        private static void ViewPassengerBaggageWeight()
        {
            Console.WriteLine(
                "========== PASSENGER BAGGAGE TOTAL ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            Passenger? passenger =
                passengerService.GetPassenger(
                    passengerId);

            Flight? flight =
                flightService.GetFlight(
                    flightNumber);

            if (passenger == null)
            {
                Console.WriteLine(
                    "Passenger does not exist.");
                return;
            }

            if (flight == null)
            {
                Console.WriteLine(
                    "Flight does not exist.");
                return;
            }

            double total =
                baggageService.GetTotalWeight(
                    passengerId,
                    flightNumber);

            double allowance =
                baggageService.GetAllowanceKg(
                    passenger.Category);

            Console.WriteLine(
                $"Passenger: {passenger.Name}");

            Console.WriteLine(
                $"Flight: {flight.FlightNumber}");

            Console.WriteLine(
                $"Cumulative baggage: {total:0.##}kg / {allowance:0.#}kg");
        }

        // =====================================================
        // 9. BOOK PASSENGER
        // =====================================================

        private static void BookPassenger()
        {
            Console.WriteLine(
                "========== BOOK PASSENGER ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            OperationResult result =
                bookingService.BookPassenger(
                    passengerId,
                    flightNumber);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 10. CANCEL CONFIRMED BOOKING
        // =====================================================

        private static void CancelBooking()
        {
            Console.WriteLine(
                "========== CANCEL CONFIRMED BOOKING ==========");

            string passengerId =
                InputHelper.ReadNonEmpty(
                    "Enter Passenger ID: ");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            OperationResult result =
                bookingService.CancelConfirmedBooking(
                    passengerId,
                    flightNumber);

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 11. VIEW STANDBY LIST
        // =====================================================

        private static void ViewStandbyList()
        {
            Console.WriteLine(
                "========== STANDBY LIST ==========");

            string flightNumber =
                InputHelper.ReadNonEmpty(
                    "Enter Flight Number: ");

            Flight? flight =
                flightService.GetFlight(
                    flightNumber);

            if (flight == null)
            {
                Console.WriteLine(
                    "Flight does not exist.");
                return;
            }

            IReadOnlyList<Booking> standby =
                bookingService.GetStandbyList(
                    flightNumber);

            if (standby.Count == 0)
            {
                Console.WriteLine(
                    "Standby list is empty.");
                return;
            }

            for (int i = 0; i < standby.Count; i++)
            {
                Booking booking = standby[i];

                Console.WriteLine(
                    $"{i + 1}. Passenger {booking.PassengerId} | Booking {booking.BookingId}");
            }
        }

        // =====================================================
        // 12. ASSIGN STAFF
        // =====================================================

        private static void AssignStaff()
        {
            Console.WriteLine(
                "========== ASSIGN GROUND STAFF ==========");

            string staffId =
                InputHelper.ReadNonEmpty(
                    "Enter Staff ID: ");

            AssignmentTargetType targetType =
                InputHelper.ReadEnumChoice<AssignmentTargetType>(
                    "Choose Assignment Target:");

            OperationResult result;

            if (targetType ==
                AssignmentTargetType.Flight)
            {
                string flightNumber =
                    InputHelper.ReadNonEmpty(
                        "Enter Flight Number: ");

                result =
                    staffService.AssignToFlight(
                        staffId,
                        flightNumber);
            }
            else
            {
                string targetName =
                    InputHelper.ReadNonEmpty(
                        "Enter Gate / Facility Name: ");

                DateTime start =
                    InputHelper.ReadDateTime(
                        "Enter Assignment Start (example 2026-09-01 08:00): ");

                DateTime end =
                    InputHelper.ReadDateTime(
                        "Enter Assignment End (example 2026-09-01 11:00): ");

                result =
                    staffService.AssignToGateOrFacility(
                        staffId,
                        targetName,
                        start,
                        end);
            }

            Console.WriteLine(result.Message);
        }

        // =====================================================
        // 13. VIEW STAFF DUTY HOURS
        // =====================================================

        private static void ViewStaffDutyHours()
        {
            Console.WriteLine(
                "========== STAFF DUTY HOURS ==========");

            string staffId =
                InputHelper.ReadNonEmpty(
                    "Enter Staff ID: ");

            GroundStaff? staff =
                staffService
                    .GetAllStaff()
                    .FirstOrDefault(s =>
                        s.StaffId.Equals(
                            staffId,
                            StringComparison.OrdinalIgnoreCase));

            if (staff == null)
            {
                Console.WriteLine(
                    "Staff member does not exist.");
                return;
            }

            double hours =
                staffService.GetCumulativeDutyHours(
                    staffId);

            Console.WriteLine(
                $"Staff: {staff.Name}");

            Console.WriteLine(
                $"Cumulative duty hours: {hours:0.##}/{AirportRules.MaximumStaffDutyHoursPerShift:0.#}");

            IReadOnlyList<StaffAssignment> assignments =
                staffService.GetAssignmentsForStaff(
                    staffId);

            if (assignments.Count == 0)
            {
                Console.WriteLine(
                    "No assignments found.");
                return;
            }

            Console.WriteLine(
                "Assignments:");

            foreach (StaffAssignment assignment
                     in assignments)
            {
                Console.WriteLine(
                    $"- {assignment.TargetName}: " +
                    $"{assignment.StartTime:g} to " +
                    $"{assignment.EndTime:g} " +
                    $"({assignment.DurationHours:0.##}h)");
            }
        }

        // =====================================================
        // 14. VIEW GATES
        // =====================================================

        private static void ViewGates()
        {
            Console.WriteLine(
                "========== GATES ==========");

            foreach (Gate gate
                     in flightService.GetAllGates())
            {
                string start =
                    gate.AvailabilityStart
                        .ToString(@"hh\:mm");

                string end =
                    gate.AvailabilityEnd
                        .ToString(@"hh\:mm");

                Console.WriteLine(
                    $"{gate.GateNumber} | " +
                    $"Availability {start}-{end} | " +
                    $"International: " +
                    $"{(gate.SupportsInternational ? "Yes" : "No")}");
            }
        }

        // =====================================================
        // 15. VIEW FLIGHTS
        // =====================================================

        private static void ViewFlights()
        {
            Console.WriteLine(
                "========== FLIGHTS ==========");

            IReadOnlyList<Flight> flights =
                flightService.GetAllFlights();

            if (flights.Count == 0)
            {
                Console.WriteLine(
                    "No flights registered.");
                return;
            }

            foreach (Flight flight
                     in flights.OrderBy(
                         f => f.ScheduledDeparture))
            {
                Console.WriteLine(
                    $"{flight.FlightNumber} | " +
                    $"{flight.Type} | " +
                    $"Arrival {flight.ScheduledArrival:g} | " +
                    $"Departure {flight.ScheduledDeparture:g} | " +
                    $"Seats {flight.SeatCapacity} | " +
                    $"Gate {flight.GateNumber ?? "Not assigned"} | " +
                    $"Status {flight.Status}");
            }
        }

        // =====================================================
        // 16. VIEW PASSENGERS
        // =====================================================

        private static void ViewPassengers()
        {
            Console.WriteLine(
                "========== PASSENGERS ==========");

            IReadOnlyList<Passenger> passengers =
                passengerService.GetAllPassengers();

            if (passengers.Count == 0)
            {
                Console.WriteLine(
                    "No passengers registered.");
                return;
            }

            foreach (Passenger passenger
                     in passengers)
            {
                Console.WriteLine(
                    $"{passenger.PassengerId} | " +
                    $"{passenger.Name} | " +
                    $"{passenger.Category} | " +
                    $"Connecting from: " +
                    $"{passenger.ConnectingFromFlightNumber ?? "None"}");
            }
        }

        // =====================================================
        // 17. VIEW BOOKINGS
        // =====================================================

        private static void ViewBookings()
        {
            Console.WriteLine(
                "========== BOOKINGS ==========");

            IReadOnlyList<Booking> bookings =
                bookingService.GetAllBookings();

            if (bookings.Count == 0)
            {
                Console.WriteLine(
                    "No bookings found.");
                return;
            }

            foreach (Booking booking
                     in bookings.OrderBy(
                         b => b.CreatedAt))
            {
                Console.WriteLine(
                    $"{booking.BookingId} | " +
                    $"Passenger {booking.PassengerId} | " +
                    $"Flight {booking.FlightNumber} | " +
                    $"Status {booking.Status} | " +
                    $"Created {booking.CreatedAt:g}");
            }
        }

        // =====================================================
        // INITIAL GATES
        // =====================================================

        private static void SeedGates()
        {
            gateRepository.Add(
                new Gate(
                    "G1",
                    new TimeSpan(5, 0, 0),
                    new TimeSpan(23, 0, 0),
                    true));

            gateRepository.Add(
                new Gate(
                    "G2",
                    new TimeSpan(6, 0, 0),
                    new TimeSpan(22, 0, 0),
                    false));

            gateRepository.Add(
                new Gate(
                    "G3",
                    new TimeSpan(8, 0, 0),
                    new TimeSpan(20, 0, 0),
                    true));

            gateRepository.Add(
                new Gate(
                    "G4",
                    new TimeSpan(0, 0, 0),
                    new TimeSpan(23, 59, 0),
                    true));
        }

        // =====================================================
        // INITIAL STAFF
        // =====================================================

        private static void SeedStaff()
        {
            staffRepository.Add(
                new GroundStaff(
                    "GS-100",
                    "Ahmad"));

            staffRepository.Add(
                new GroundStaff(
                    "GS-101",
                    "Sara"));

            staffRepository.Add(
                new GroundStaff(
                    "GS-102",
                    "Omar"));

            staffRepository.Add(
                new GroundStaff(
                    "GS-103",
                    "Lina"));
        }
    }
}