# Meridian Terminal — Ground Operations Management System

## How to Run

1. Open the `MeridianAirport.sln` file in Visual Studio.
2. Make sure the project is using a compatible .NET version.
3. Build the project using **Build > Build Solution**.
4. Run the application using **Ctrl + F5** or the **Start** button.
5. Use the console menu to perform the available airport ground operations.

The system uses **session-only storage**. Data is stored in memory while the program is running and is removed when the application is closed, as required by the assignment.

## Implemented Features

The system supports the following operations:

* Register new flights with domestic/international type, schedule, and seat capacity.
* Assign flights to gates and prevent overlapping gate assignments.
* Apply international gate restrictions.
* Update flight status such as Scheduled, Delayed, Boarding, Departed, and Cancelled.
* Register passengers with Standard, VIP, or Reduced Mobility categories.
* Register optional connecting flights for passengers.
* Check minimum connection time before boarding.
* Process passenger bookings with confirmed seats and standby lists.
* Automatically promote the earliest standby passenger when a confirmed seat becomes available.
* Cancel confirmed bookings.
* Register multiple baggage items and calculate cumulative baggage weight.
* Enforce baggage allowance by passenger category.
* Enforce a maximum single-bag weight.
* Prevent baggage operations after a flight has departed or been cancelled.
* Assign ground staff to flights or gates/facilities.
* Track cumulative staff duty hours.
* Prevent overlapping staff assignments.
* Prevent staff assignments that exceed the maximum shift hours.
* Display meaningful error and validation messages.

## Design Decisions

The following values were chosen as reasonable business rules for the system:

* Minimum connection time: **45 minutes**
* Standby list capacity: **5 passengers**
* Maximum staff duty time per shift: **8 hours**
* Standard baggage allowance: **30 kg**
* VIP baggage allowance: **40 kg**
* Reduced Mobility baggage allowance: **30 kg**
* Maximum single baggage item: **23 kg**
* Gate occupancy window: **Scheduled Arrival to Scheduled Departure**

## OOP and Design

The project uses C# OOP concepts including classes, objects, encapsulation, interfaces, enums, generics, and dependency injection.

The design also applies Clean Code and SOLID principles where appropriate, while keeping the implementation simple enough for a console-based assignment.
